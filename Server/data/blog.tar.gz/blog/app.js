require('hexo').init({command:'server'});
